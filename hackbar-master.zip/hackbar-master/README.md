# HackBar Modded Version Repository.
This is the OpenSource project of the same HackBar which is Presently available as H5H Mod. Check it out here, https://addons.mozilla.org/en-US/firefox/addon/~h3ll4r_h5h-hackmod/?src=userprofile.

We need your suggestions and your contribution to run this Project as much as we all can. We Request you to Drop Any Mail 
Suggestions can be Dropped at iamthelord287@gmail.com
